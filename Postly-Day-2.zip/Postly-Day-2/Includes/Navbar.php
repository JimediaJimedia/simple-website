<body>
 
<div class="bg-danger p-2">
<h3 class="text-light">
    <a href="<?= APP_HOME; ?>" class="navbrand"><?= APP_NAME; ?></a>
</h3>
</div>