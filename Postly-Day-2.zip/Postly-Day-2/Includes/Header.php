<?php require('Config/App.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=nos">
    <title>Home | <?= APP_DESC; ?></title>
    <link rel="stylesheet" href="<?= APP_HOME; ?>Assets/Styles/css/bootstrap.css">
    <link rel="stylesheet" href="<?= APP_HOME; ?>Assets/Styles/css/app.css?<?= rand(); ?>">
</head>

    <?php include('Includes/Navbar.php'); ?>
