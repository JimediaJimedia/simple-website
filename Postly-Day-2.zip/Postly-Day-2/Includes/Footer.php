<p class='text-center mt-5'>
&copy; 2024 - All right reserved <?= APP_NAME; ?>
</p>

</body>

</html>