<?php

# Loading the Required files

require('Auto/autoload.php');