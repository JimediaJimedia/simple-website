<?php 

require('Config/Conn.php');


define('APP_NAME', 'Postly');
define('APP_DESC', 'The blog mate house');

define('APP_ROOT', 'Assets/Uploads/');

define('APP_HOME', 'http://192.168.43.237/postly/');



require('Auth/Auth.php');
require('Auth/Misc.php');
require('Config/DB/Queries.php');

