<?php

include('Includes/Header.php');
include('Auth/NotLoggedin.php');
include('Includes/Intro.php');
include('Includes/Posts.php');
include('Includes/Footer.php');